import { createReducer, on } from '@ngrx/store';
